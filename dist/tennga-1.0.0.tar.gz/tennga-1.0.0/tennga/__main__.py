

#使用 "python -m 包名" 调用本文件
if __name__ == "__main__":
    pass